Cufon.replace('h1 , h2', { fontFamily: 'OliJo' });
Cufon.replace('nav ul li a', { fontFamily: 'OliJo', hover: 'true' });
Cufon.replace('h1, h1 span, h1 span span, h2', { fontFamily: 'OliJo' });